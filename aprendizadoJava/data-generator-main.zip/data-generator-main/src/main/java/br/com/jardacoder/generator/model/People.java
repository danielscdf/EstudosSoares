package br.com.jardacoder.generator.model;

public class People {

}
