package com.jardacoder.strategy.demo.enums;

public enum NotificationType {

	EMAIL,
	WHATSAPP
}
