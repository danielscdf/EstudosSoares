package com.jardacoder.strategy.demo.interfaces;

public interface StrategyBase<T> {
	
	T getStrategyName();

}
