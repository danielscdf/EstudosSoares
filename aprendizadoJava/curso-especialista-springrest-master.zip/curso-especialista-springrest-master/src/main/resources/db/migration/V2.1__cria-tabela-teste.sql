create table teste (
	id bigint not null auto_increment,
	
	primary key (id)
)engine=InnoDB charset=utf8;