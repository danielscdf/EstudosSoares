package com.algaworks.algafood.api.v1.controller.openapi.model;

import com.algaworks.algafood.api.v1.model.PedidoResumoDto;

import io.swagger.annotations.ApiModel;

@ApiModel("PedidosDto")
public class PedidosResumoDtoOpenApi extends PagedDtoOpenApi<PedidoResumoDto> {

}
