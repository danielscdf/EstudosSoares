package com.algaworks.algafood.domain.enums;

public enum Frete {
	
	NORMAL,
	EXPRESSO;
}	
