package com.algaworks.algafood.domain.enums;

public enum Notificador {
	EMAIL,
	SMS ;
}
