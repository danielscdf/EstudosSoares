package com.algaworks.algafood.core.validation;

public interface Groups {
	
	public interface EstadoId{}

	public interface CozinhaId{}
}
