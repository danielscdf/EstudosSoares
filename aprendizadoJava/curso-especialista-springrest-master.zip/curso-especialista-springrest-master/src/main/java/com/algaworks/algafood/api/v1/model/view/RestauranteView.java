package com.algaworks.algafood.api.v1.model.view;

public interface RestauranteView {
//	
//	public interface Resumo{
//		
//	}
//	
//	public interface ApenasNome{
//		
//	}

}
