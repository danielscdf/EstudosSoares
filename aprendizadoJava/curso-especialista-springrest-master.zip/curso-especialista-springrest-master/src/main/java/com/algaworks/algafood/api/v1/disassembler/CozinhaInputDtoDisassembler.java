package com.algaworks.algafood.api.v1.disassembler;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.algaworks.algafood.api.v1.model.input.CozinhaInputDto;
import com.algaworks.algafood.domain.model.Cozinha;

@Component
public class CozinhaInputDtoDisassembler {
	
	@Autowired
	private ModelMapper modelMapper;

	public Cozinha cozinhaInputDtoToCidade(CozinhaInputDto cozinhaInputDto) {
		return modelMapper.map(cozinhaInputDto, Cozinha.class);
	}
	
	public void copyToDomainObject(CozinhaInputDto cozinhaInputDto, Cozinha cozinha) {
		modelMapper.map(cozinhaInputDto, cozinha);
	}
}
